//
//  FileDragView.h
//  DragDropDemo
//
//  Created by Louis Luo on 2021/6/24.
//  Copyright © 2021 Suncode. All rights reserved.

#import <Cocoa/Cocoa.h>

@interface FileDragView : NSTextField

@end
