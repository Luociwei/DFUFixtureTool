//
//  WindowVC.h
//  DfuDebugTool
//
//  Created by ciwei luo on 2021/2/28.
//  Copyright © 2021 macdev. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ExtensionConst.h"
#import "EditCmdsVC.h"
NS_ASSUME_NONNULL_BEGIN

@interface WindowVC : WindowController

@end

NS_ASSUME_NONNULL_END
