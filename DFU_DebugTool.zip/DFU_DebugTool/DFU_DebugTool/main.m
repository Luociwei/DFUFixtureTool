//
//  main.m
//  DFU_DebugTool
//
//  Created by Louis Luo on 2021/3/31.
//  Copyright © 2021 Suncode. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
