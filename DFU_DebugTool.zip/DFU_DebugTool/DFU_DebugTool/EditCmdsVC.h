//
//  EditCmdsVC.h
//  DfuDebugTool
//
//  Created by ciwei luo on 2021/2/28.
//  Copyright © 2021 macdev. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CwGeneralManagerFrameWork/PresentViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface EditCmdsVC : PresentViewController

@end

NS_ASSUME_NONNULL_END
