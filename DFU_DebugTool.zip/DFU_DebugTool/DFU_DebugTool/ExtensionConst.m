//
//  ExtensionConst.m
//  OPP_Tool
//
//  Created by Louis Luo on 2021/7/16.
//  Copyright © 2021 Suncode. All rights reserved.
//

#import "ExtensionConst.h"

@implementation ExtensionConst

int const snLength = 12;
NSString *const plistName = @"datas";//@"N/A"
NSString *const slot1_FixtureLog = @"Slot1_FixtureLog";//@"N/A"
NSString *const slot2_FixtureLog = @"Slot2_FixtureLog";//@"N/A"
NSString *const slot3_FixtureLog = @"Slot3_FixtureLog";//@"N/A"
NSString *const slot4_FixtureLog = @"Slot4_FixtureLog";//@"N/A"

NSString *const slot1_DUTLog = @"Slot1_DUTLog";//@"N/A"
NSString *const slot2_DUTLog = @"Slot2_DUTLog";//@"N/A"
NSString *const slot3_DUTLog = @"Slot3_DUTLog";//@"N/A"
NSString *const slot4_DUTLog = @"Slot4_DUTLog";//@"N/A"
@end
