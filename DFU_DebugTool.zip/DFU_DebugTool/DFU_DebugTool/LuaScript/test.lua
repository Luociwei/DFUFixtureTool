


local cmd = "eeprom.write_string(0,?)"
if string.find(cdm,'%%?') then print(sssss) end
cmd = string.gsub(cmd,"%?", 'ssfsdfsfaafads')

print(cmd)

local reply = [[
PING 169.254.1.32 (169.254.1.32): 56 data bytes

--- 169.254.1.32 ping statistics ---
1 packets transmitted, 0 packets received, 100.0% packet loss
----end
]]

-- or string.match(reply,'(icmp_seq=%d+%sttl=)') 
-- local a,b = string.find(reply,', 0.0%% packet loss')
-- print(a)
-- print(b)
-- if string.find(reply,'0.0%% packet loss') then
-- 	-- return true
-- 	print('true')
-- else
-- 	-- return false
-- 	print('false')
-- end

-- local common = require("Common")

-- function test()
--     local isok = common.pingIP('192.168.1.1')
--     print('isok:'..tostring(isok))
-- end

-- test()
