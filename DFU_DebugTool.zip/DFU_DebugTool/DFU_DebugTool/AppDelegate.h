//
//  WindowVC.h
//  DFU_DebugTool
//
//  Created by Louis Luo on 2021/3/31.
//  Copyright © 2021 Suncode. All rights reserved.
//


#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

