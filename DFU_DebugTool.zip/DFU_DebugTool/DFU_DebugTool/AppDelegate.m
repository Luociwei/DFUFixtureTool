//
//  WindowVC.h
//  DFU_DebugTool
//
//  Created by Louis Luo on 2021/3/31.
//  Copyright © 2021 Suncode. All rights reserved.
//


#import "AppDelegate.h"
#import "WindowVC.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application

}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
