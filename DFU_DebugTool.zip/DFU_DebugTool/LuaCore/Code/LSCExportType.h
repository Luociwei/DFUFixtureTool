//
//  LSCExportModule.h
//  LuaCore
//
//  Created by 冯鸿杰 on 2017/9/5.
//  Copyright © 2017年 vimfung. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 导出模块协议，实现此协议可以将模块导出到Lua层使用
 */
@protocol LSCExportType <NSObject>

@end
